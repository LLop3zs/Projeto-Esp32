package com.mensagem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoMensagemApplicationTests {

	@Test
	void contextLoads() {
	}

}
