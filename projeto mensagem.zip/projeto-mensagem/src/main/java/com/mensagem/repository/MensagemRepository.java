package com.mensagem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mensagem.entities.Mensagem;

@Repository
	public interface MensagemRepository extends JpaRepository<Mensagem, Long>{
	
}
