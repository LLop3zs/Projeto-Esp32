package com.mensagem.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mensagem.entities.Mensagem;
import com.mensagem.repository.MensagemRepository;


@Service 
public class MensagemService {

		@Autowired
		private MensagemRepository repository;
		


		public List<Mensagem> listarTodos() {
			return repository.findAll();
		}

		public Optional<Mensagem> buscarPorId(Long id) {
			return repository.findById(id);
		}

		public Mensagem salvar(Mensagem mensagem) {
			
			Mensagem mensagem1 = new Mensagem();
			
			mensagem1.setConteudo(mensagem1.getConteudo());
			mensagem1.setDataHora(mensagem1.getDataHora());
		
			
			
			
			
			return repository.save(mensagem1);
		}

		public Mensagem atualizar(Long id, Mensagem mensagemAlterada) {
			Optional <Mensagem> existente = buscarPorId(id);
			
			if(existente.isPresent()) {
				
				Mensagem atualizado = existente.get();
				
			atualizado.setConteudo(mensagemAlterada.getConteudo());
			atualizado.setDataHora(mensagemAlterada.getDataHora());

			if(mensagemAlterada.getConteudo() != null) {
				atualizado.setConteudo(mensagemAlterada.getConteudo());

			}
					return repository.save(atualizado);

			
			}
			return null;
		}

		public void deletar(Long id) {
			repository.deleteById(id);
		}

		public Mensagem cadastrar(Mensagem mensagem) {
			// TODO Auto-generated method stub
			return null;
		}
}
