package com.registroled;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoRegistroLedApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoRegistroLedApplication.class, args);
	}

}
