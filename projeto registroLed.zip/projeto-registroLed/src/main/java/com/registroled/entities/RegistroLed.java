package com.registroled.entities;

import java.time.LocalDateTime;

import com.registroled.enums.Acao;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_registroLed")
public class RegistroLed {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false)
	private Acao acao;

	@Column(nullable = false)
	private boolean ledAcesso;

	@Column(nullable = false)
	private LocalDateTime dataHora;

	public RegistroLed() {
	}

	public RegistroLed(Acao acao, Long id, boolean ledAcesso, LocalDateTime dataHora) {
		this.dataHora = dataHora;
		this.id = id;
		this.ledAcesso = ledAcesso;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public boolean isLedAcesso() {
		return ledAcesso;
	}

	public void setLedAcesso(boolean ledAcesso) {
		this.ledAcesso = ledAcesso;
	}

	public LocalDateTime getDataHora() {
		return dataHora;
	}

	public void setDataHora(LocalDateTime dataHora) {
		this.dataHora = dataHora;
	}

	public Acao getAcao() {
		return acao;
	}

	public void setAcao(Acao acao) {
		this.acao = acao;
	}

}
