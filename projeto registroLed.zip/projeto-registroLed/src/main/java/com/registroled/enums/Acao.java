package com.registroled.enums;

public enum Acao {

	Ligar, Desligar
}
