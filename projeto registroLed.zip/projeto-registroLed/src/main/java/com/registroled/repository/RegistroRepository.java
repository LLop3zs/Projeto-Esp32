package com.registroled.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.registroled.entities.RegistroLed;

public interface RegistroRepository extends JpaRepository<RegistroLed, Long> {

}
