package com.registroled.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.registroled.entities.RegistroLed;
import com.registroled.service.RegistroService;

@RestController
@RequestMapping("/registro")
@CrossOrigin("*")
public class RegistroController {

	private final RegistroService registroService;

    public RegistroController(RegistroService registroService) {
        this.registroService = registroService;
    }

    @PostMapping
    public ResponseEntity<RegistroLed> cadastrar(@RequestBody RegistroLed registroLed) {
        RegistroLed registroSalvo = registroService.cadastrar(registroLed);
        return ResponseEntity.status(HttpStatus.CREATED).body(registroSalvo);
    }

    @GetMapping
    public ResponseEntity<List<RegistroLed>> listar() {
        return ResponseEntity.ok(registroService.listarTodos());
    }
    @PutMapping("/{id}")
    public ResponseEntity<RegistroLed> atualizar(@PathVariable Long id, @RequestBody RegistroLed registroLed) {
        return ResponseEntity.ok(registroService.atualizar(id, registroLed));
    }
}