package com.registroled.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.registroled.entities.RegistroLed;
import com.registroled.repository.RegistroRepository;

public class RegistroService {

	@Autowired
	private RegistroRepository repository;

	public List<RegistroLed> listarTodos() {
		return repository.findAll();
	}

	public Optional<RegistroLed> buscarPorId(Long id) {
		return repository.findById(id);
	}

	public RegistroLed salvar(RegistroLed registro) {

		RegistroLed registro1 = new RegistroLed();

		registro.setLedAcesso(registro1.isLedAcesso());
		registro.setDataHora(registro1.getDataHora());

		return repository.save(registro1);
	}

	public RegistroLed atualizar(Long id, RegistroLed registroAlterada) {
		Optional<RegistroLed> existente = buscarPorId(id);

		if (existente.isPresent()) {

			RegistroLed atualizado = existente.get();

			atualizado.setLedAcesso(registroAlterada.isLedAcesso());
			atualizado.setDataHora(registroAlterada.getDataHora());

			if (registroAlterada.isLedAcesso()) {
				atualizado.setLedAcesso(registroAlterada.isLedAcesso());

			}
			return repository.save(atualizado);

		}
		return null;
	}

	public void deletar(Long id) {
		repository.deleteById(id);
	}

	public RegistroLed cadastrar(RegistroLed registroLed) {
		// TODO Auto-generated method stub
		return null;
	}

}
