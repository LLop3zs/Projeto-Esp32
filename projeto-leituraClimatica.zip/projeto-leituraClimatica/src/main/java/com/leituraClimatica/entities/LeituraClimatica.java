package com.leituraClimatica.entities;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_leituraClimatica")
public class LeituraClimatica {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	
	@Column(nullable = false)
	private double temperatura;
	
	@Column(nullable = false)
	private double umidade;
	
	@Column(nullable = false)
	private LocalDateTime dataHora;
	
	public LeituraClimatica() {}
	
	public LeituraClimatica (Long id, double temperatura, double umidade, LocalDateTime dataHora) {
		this.dataHora = dataHora;
		this.id = id;
		this.temperatura = temperatura;
		this.umidade = umidade;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public double getTemperatura() {
		return temperatura;
	}

	public void setTemperatura(double temperatura) {
		this.temperatura = temperatura;
	}

	public double getUmidade() {
		return umidade;
	}

	public void setUmidade(double umidade) {
		this.umidade = umidade;
	}

	public LocalDateTime getDataHora() {
		return dataHora;
	}

	public void setDataHora(LocalDateTime dataHora) {
		this.dataHora = dataHora;
	}
	
}
