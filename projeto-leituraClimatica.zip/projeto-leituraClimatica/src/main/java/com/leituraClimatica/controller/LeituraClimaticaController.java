package com.leituraClimatica.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.leituraClimatica.entities.LeituraClimatica;
import com.leituraClimatica.service.LeituraClimaticaService;



@RestController
@RequestMapping("/api/leituraClimatica")
@CrossOrigin("*")
public class LeituraClimaticaController {

	@Autowired
	private final LeituraClimaticaService leituraClimaticaService;

    public LeituraClimaticaController(LeituraClimaticaService leituraClimaticaService) {
        this.leituraClimaticaService = leituraClimaticaService;
    }

    @PostMapping
    public ResponseEntity<LeituraClimatica> cadastrar(@RequestBody LeituraClimatica leituraClimatica) {
    	LeituraClimatica leituraClimaticaSalvo = leituraClimaticaService.cadastrar(leituraClimatica);
        return ResponseEntity.status(HttpStatus.CREATED).body(leituraClimaticaSalvo);
    }

    @GetMapping
    public ResponseEntity<List<LeituraClimatica>> listar() {
        return ResponseEntity.ok(leituraClimaticaService.listarTodos());
    }
    @PutMapping("/{id}")
    public ResponseEntity<LeituraClimatica> atualizar(@PathVariable Long id, @RequestBody LeituraClimatica lituraClimatica) {
        return ResponseEntity.ok(leituraClimaticaService.atualizar(id, leituraClimaticaService));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
    	leituraClimaticaService.deletar(id);
        return ResponseEntity.noContent().build();
    }
}

