package com.leituraClimatica.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.leituraClimatica.entities.LeituraClimatica;

public interface LeituraClimaticaRepository extends JpaRepository<LeituraClimatica, Long> {

}
