package com.leituraClimatica.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.leituraClimatica.entities.LeituraClimatica;
import com.leituraClimatica.repository.LeituraClimaticaRepository;

public class LeituraClimaticaService {

	
	@Autowired
	private LeituraClimaticaRepository repository;
	


	public List<LeituraClimatica> listarTodos() {
		return repository.findAll();
	}

	public Optional<LeituraClimatica> buscarPorId(Long id) {
		return repository.findById(id);
	}

	public LeituraClimatica salvar(LeituraClimatica leituraClimatica) {
		
		LeituraClimatica LeituraClimatica1 = new LeituraClimatica();
		
		LeituraClimatica1.setTemperatura(LeituraClimatica1.getTemperatura());
		LeituraClimatica1.setUmidade(LeituraClimatica1.getUmidade());
		LeituraClimatica1.setDataHora(LeituraClimatica1.getDataHora());
	
		
		
		
		
		return repository.save(LeituraClimatica1);
	}

	public LeituraClimatica atualizar(Long id, LeituraClimaticaService leituraClimaticaService) {
		Optional <LeituraClimatica> existente = buscarPorId(id);
		
		if(existente.isPresent()) {
			
			LeituraClimatica atualizado = existente.get();
			
		atualizado.setTemperatura(leituraClimaticaService.getTemperatura());
		atualizado.setDataHora(leituraClimaticaService.getDataHora());
		atualizado.setUmidade(leituraClimaticaService.getUmidade());

        }
			
		
		
		return null;
	}

	private double getUmidade() {
		// TODO Auto-generated method stub
		return 0;
	}

	private LocalDateTime getDataHora() {
		// TODO Auto-generated method stub
		return null;
	}

	private double getTemperatura() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void deletar(Long id) {
		repository.deleteById(id);
	}

	public LeituraClimatica cadastrar(LeituraClimatica leituraClimatica) {
		// TODO Auto-generated method stub
		return null;
	}
}
	

