package com.registropotenciometro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.registropotenciometro.entities.RegistroPotenciometro;
import com.registropotenciometro.repository.RegistroPotenciaometroRepository;

@Service
public class RegistroPotenciometroService {

    @Autowired
    private RegistroPotenciaometroRepository repository;

    public RegistroPotenciometro salvar(RegistroPotenciometro registro) {
        return repository.save(registro);
    }

    public List<RegistroPotenciometro> listarTodos() {
        return repository.findAll();
    }
}