package com.registropotenciometro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoRegistroPotenciometroApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoRegistroPotenciometroApplication.class, args);
	}

}
