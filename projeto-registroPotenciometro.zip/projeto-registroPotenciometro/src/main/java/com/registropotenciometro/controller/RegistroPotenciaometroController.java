package com.registropotenciometro.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.registropotenciometro.entities.RegistroPotenciometro;
import com.registropotenciometro.service.RegistroPotenciometroService;

@RestController
@RequestMapping("/api/potenciometro")
@CrossOrigin(origins = "*")
public class RegistroPotenciaometroController {
 
    @Autowired
    private RegistroPotenciometroService service;

    @PostMapping
    public ResponseEntity<RegistroPotenciometro> criar(@RequestBody RegistroPotenciometro registro) {
        RegistroPotenciometro salvo = service.salvar(registro);
        return ResponseEntity.status(HttpStatus.CREATED).body(salvo);
    }

    @GetMapping
    public ResponseEntity<List<RegistroPotenciometro>> listar() {
        List<RegistroPotenciometro> lista = service.listarTodos();
        return ResponseEntity.ok(lista);
    }
}