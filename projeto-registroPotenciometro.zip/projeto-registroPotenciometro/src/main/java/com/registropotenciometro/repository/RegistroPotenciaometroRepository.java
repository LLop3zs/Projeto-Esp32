package com.registropotenciometro.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.registropotenciometro.entities.RegistroPotenciometro;

public interface RegistroPotenciaometroRepository extends JpaRepository<RegistroPotenciometro, Long>{

}
