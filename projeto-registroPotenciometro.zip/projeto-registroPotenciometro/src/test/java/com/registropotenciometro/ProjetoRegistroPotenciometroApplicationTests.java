package com.registropotenciometro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoRegistroPotenciometroApplicationTests {

	@Test
	void contextLoads() {
	}

}
